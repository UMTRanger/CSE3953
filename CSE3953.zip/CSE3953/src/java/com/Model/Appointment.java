package com.Model;

import java.sql.Date;
import java.sql.Time;

public class Appointment {
    private int appointment_id;
    private String patient_username;
    private String appointmentDate;
    private String appointmentTime;
    private String doctor_id;
    
    public Appointment(){
        
    }
    
    public Appointment(int id, String p_username, String date, String time, String doctor_id){
        appointment_id = id;
        patient_username = p_username;
        appointmentDate = date;
        appointmentTime = time;
        this.doctor_id = doctor_id;
    }
    
    public Appointment(String p_username, String date, String time, String doctor_id){
        patient_username = p_username;
        appointmentDate = date;
        appointmentTime = time;
        this.doctor_id = doctor_id;
    }

    public int getAppointment_id() {
        return appointment_id;
    }

    public void setAppointment_id(int appointment_id) {
        this.appointment_id = appointment_id;
    }

    public String getPatient_username() {
        return patient_username;
    }

    public void setPatient_username(String patient_username) {
        this.patient_username = patient_username;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public String getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(String doctor_id) {
        this.doctor_id = doctor_id;
    }


    
    
}
