package com.Model;

public class Update {
    private String updateid;
    private String updateContent;
    private String updatedBy;
    
    public Update(){
        
    }
    
    public Update(String updateid, String updateContent, String updatedBy){
        this.updateid = updateid;
        this.updateContent = updateContent;
        this.updatedBy = updatedBy;
    }
    
    public Update(String updateContent, String updatedBy){
        this.updateContent = updateContent;
        this.updatedBy = updatedBy;
    }

    public String getUpdateid() {
        return updateid;
    }

    public void setUpdateid(String updateid) {
        this.updateid = updateid;
    }

    public String getUpdateContent() {
        return updateContent;
    }

    public void setUpdateContent(String updateContent) {
        this.updateContent = updateContent;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }        
}
