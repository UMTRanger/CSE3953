package com.Model;

public class Doctor {
    private String doctor_username;
    private String doctor_password;
    private String doctor_name;
    private String doctor_phonenumber;
    private String specialty;
    
    public Doctor(){}
    
    public Doctor(String username, String password, String name, String phonenumber,  String specialty){
        doctor_name = name;
        doctor_phonenumber = phonenumber;
        doctor_username = username;
        doctor_password = password;
        this.specialty = specialty;
    }

    public String getDoctor_name() {
        return doctor_name;
    }

    public void setDoctor_name(String doctor_name) {
        this.doctor_name = doctor_name;
    }

    public String getDoctor_phonenumber() {
        return doctor_phonenumber;
    }

    public void setDoctor_phonenumber(String doctor_phonenumber) {
        this.doctor_phonenumber = doctor_phonenumber;
    }

    public String getDoctor_username() {
        return doctor_username;
    }

    public void setDoctor_username(String doctor_username) {
        this.doctor_username = doctor_username;
    }

    public String getDoctor_password() {
        return doctor_password;
    }

    public void setDoctor_password(String doctor_password) {
        this.doctor_password = doctor_password;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }
}
