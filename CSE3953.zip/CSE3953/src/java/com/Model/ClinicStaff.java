package com.Model;

public class ClinicStaff {
    private String staff_name;
    private String staff_phonenumber;
    private String staff_username;
    private String staff_password;
    
    public ClinicStaff(){}
    
    public ClinicStaff(String username, String name, String phonenumber, String password){
        this.staff_name = name;
        this.staff_phonenumber = phonenumber;
        this.staff_username = username;
        this.staff_password = password;
    }

    public String getStaff_name() {
        return staff_name;
    }

    public void setStaff_name(String staff_name) {
        this.staff_name = staff_name;
    }

    public String getStaff_phonenumber() {
        return staff_phonenumber;
    }

    public void setStaff_phonenumber(String staff_phonenumber) {
        this.staff_phonenumber = staff_phonenumber;
    }

    public String getStaff_username() {
        return staff_username;
    }

    public void setStaff_username(String staff_username) {
        this.staff_username = staff_username;
    }

    public String getStaff_password() {
        return staff_password;
    }

    public void setStaff_password(String staff_password) {
        this.staff_password = staff_password;
    }
}
