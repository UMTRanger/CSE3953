package com.Model;

import java.sql.Date;

public class Availability {

    private int available_id;
    private String doctor_username;
    private String unavailableDate;
    private String reason;

    public Availability() {

    }

    public Availability(int a_id, String d_username, String unavailable_date, String reason) {
        available_id = a_id;
        doctor_username = d_username;
        unavailableDate = unavailable_date;
        this.reason = reason;
    }

    public Availability(String d_username, String unavailable_date, String reason) {
        doctor_username = d_username;
        unavailableDate = unavailable_date;
        this.reason = reason;
    }

    public int getAvailable_id() {
        return available_id;
    }

    public void setAvailable_id(int available_id) {
        this.available_id = available_id;
    }

    public String getDoctor_username() {
        return doctor_username;
    }

    public void setDoctor_username(String doctor_username) {
        this.doctor_username = doctor_username;
    }

    public String getUnavailableDate() {
        return unavailableDate;
    }

    public void setUnavailableDate(String unavailableDate) {
        this.unavailableDate = unavailableDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
