package com.Model;

public class PatientRecord {
    private int record_id;
    private String patient_username;
    private String appointment_date;
    private String diagnosis;
    private String treatment;
    private String prescription;
    private String labresult;
    private String doctor_username;
    
    public PatientRecord(){
        
    }
    
    public PatientRecord(int id, String username, String appointment_date, String diagnosis, String treatment, String prescription, String labresult, String doctor_username){
        record_id = id;
        patient_username = username;
        this.appointment_date = appointment_date;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.prescription = prescription;
        this.labresult = labresult;
        this.doctor_username = doctor_username;
    }
    
    public PatientRecord(String username, String appointment_date, String diagnosis, String treatment, String prescription, String labresult, String doctor_username){
        patient_username = username;
        this.appointment_date = appointment_date;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
        this.prescription = prescription;
        this.labresult = labresult;
        this.doctor_username = doctor_username;
    }

    public int getRecord_id() {
        return record_id;
    }

    public void setRecord_id(int record_id) {
        this.record_id = record_id;
    }

    public String getPatient_username() {
        return patient_username;
    }

    public void setPatient_username(String patient_username) {
        this.patient_username = patient_username;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getPrescription() {
        return prescription;
    }

    public void setPrescription(String prescription) {
        this.prescription = prescription;
    }

    public String getLabresult() {
        return labresult;
    }

    public void setLabresult(String labresult) {
        this.labresult = labresult;
    }

    public String getDoctor_username() {
        return doctor_username;
    }

    public void setDoctor_username(String doctor_username) {
        this.doctor_username = doctor_username;
    }

    public String getAppointment_date() {
        return appointment_date;
    }

    public void setAppointment_date(String appointment_date) {
        this.appointment_date = appointment_date;
    }
}
