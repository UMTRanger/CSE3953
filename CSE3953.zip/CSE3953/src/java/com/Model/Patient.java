package com.Model;

public class Patient {
    private String patient_username;
    private String patient_password;
    private String patient_name;
    private String patient_icnumber;
    private String patient_email;
    private String patient_gender;
    private String patient_phonenumber;
        
    public Patient(){}
    
    public Patient(String password, String name, String icnumber, String email, String gender, String phonenumber){
        patient_name = name;
        patient_phonenumber = phonenumber;
        patient_icnumber = icnumber;
        patient_email = email;
        patient_password = password;
        patient_gender = gender;
    }
    
    public Patient(String username, String password, String name, String icnumber, String email, String gender, String phonenumber){
        patient_name = name;
        patient_phonenumber = phonenumber;
        patient_icnumber = icnumber;
        patient_email = email;
        patient_username = username;
        patient_password = password;
        patient_gender = gender;
    }

    public String getPatient_name() {
        return patient_name;
    }

    public void setPatient_name(String patient_name) {
        this.patient_name = patient_name;
    }
    
    public String getPatient_gender() {
        return patient_gender;
    }

    public void setPatient_gender(String patient_gender) {
        this.patient_gender = patient_gender;
    }

    public String getPatient_phonenumber() {
        return patient_phonenumber;
    }

    public void setPatient_phonenumber(String patient_phonenumber) {
        this.patient_phonenumber = patient_phonenumber;
    }

    public String getPatient_username() {
        return patient_username;
    }

    public void setPatient_username(String patient_username) {
        this.patient_username = patient_username;
    }

    public String getPatient_password() {
        return patient_password;
    }

    public void setPatient_password(String patient_password) {
        this.patient_password = patient_password;
    }

    public String getPatient_icnumber() {
        return patient_icnumber;
    }

    public void setPatient_icnumber(String patient_icnumber) {
        this.patient_icnumber = patient_icnumber;
    }

    public String getPatient_email() {
        return patient_email;
    }

    public void setPatient_email(String patient_email) {
        this.patient_email = patient_email;
    }
}
