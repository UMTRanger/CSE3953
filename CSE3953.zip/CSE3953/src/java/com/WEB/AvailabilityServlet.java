package com.WEB;

import com.DAO.AvailabilityDAO;
import com.Model.Availability;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/availability/*")
public class AvailabilityServlet extends HttpServlet {

    private AvailabilityDAO availabilityDAO;

    public void init() {
        availabilityDAO = new AvailabilityDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/leave":
                    takeLeave(request, response);
                    break;

                case "/delete":
                    deleteLeave(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);

        }
    }

    public void takeLeave(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        PrintWriter out = response.getWriter();

        String username = request.getParameter("username");
        String unavailableDate = request.getParameter("date");
        String reason = request.getParameter("reason");

        Availability newAvailable = new Availability(username, unavailableDate, reason);

        availabilityDAO.insertLeave(newAvailable);
        out.println("<script type=\"text/javascript\">");
        out.println("alert('Leave Applied!');");
        out.println("window.location.href = '" + request.getContextPath() + "/doctor/home';");
        out.println("</script>");
    }

    public void deleteLeave(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        PrintWriter out = response.getWriter();
        int id = Integer.parseInt(request.getParameter("availability_id"));
        System.out.println("Deleting " + id);
        boolean delete_success = availabilityDAO.deleteDate(id);

        if (delete_success) {
            System.out.println(id+ "deleted successfully");
            RequestDispatcher rd = request.getRequestDispatcher("/staff/home");
            rd.forward(request, response);
        } else {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Failed to delete Leave!');");
            out.println("window.location.href = '" + request.getContextPath() + "/staff/home';");
            out.println("</script>");
        }

    }
}
