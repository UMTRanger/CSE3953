/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.WEB;

import com.DAO.ClinicStaffDAO;
import com.DAO.UpdateDAO;
import com.Model.ClinicStaff;
import com.Model.Update;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/update/*")
public class UpdateServlet extends HttpServlet {

    private UpdateDAO updateDAO;
    private ClinicStaffDAO staffDAO;

    public void init() {
        updateDAO = new UpdateDAO();
        staffDAO = new ClinicStaffDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/list":
                    viewUpdateList(request, response);
                    break;

                case "/form":
                    updateForm(request, response);
                    break;

                case "/new":
                    addUpdate(request, response);
                    break;

                case "/edit":
                    editForm(request, response);
                    break;
                    
                case "/update":
                    updateUpdate(request,response);
                    break;
                    
                case "/delete":
                    deleteUpdate(request, response);
                    break;

            }
        } catch (SQLException ex) {
            throw new ServletException(ex);

        }
    }

    private void viewUpdateList(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        List<Update> listUpdate = updateDAO.selectAllUpdates();
        request.setAttribute("listUpdate", listUpdate);

        RequestDispatcher rd = request.getRequestDispatcher("/clinicUpdate.jsp");
        rd.forward(request, response);
    }

    private void updateForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        HttpSession session = request.getSession();

        String username = (String) session.getAttribute("username");
        ClinicStaff usingStaff = staffDAO.selectStaffByUsername(username);

        RequestDispatcher rd = request.getRequestDispatcher("/createUpdate.jsp");
        request.setAttribute("staff", usingStaff);
        rd.forward(request, response);
    }

    private void addUpdate(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        PrintWriter out = response.getWriter();

        String staff_username = request.getParameter("updateBy");
        String content = request.getParameter("content");

        Update update = new Update(content, staff_username);

        updateDAO.insertUpdate(update);
        out.println("<script type=\"text/javascript\">");
        out.println("alert('Update Created!');");
        out.println("window.location.href = '" + request.getContextPath() + "/update/list';");
        out.println("</script>");
    }
    
    private void editForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("update_id"));
        Update update = updateDAO.selectPatient(id);
        
        RequestDispatcher rd = request.getRequestDispatcher("/editUpdate.jsp");
        request.setAttribute("update", update);
        rd.forward(request, response);
    }
    
    
    private void updateUpdate(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        String updateid = request.getParameter("update_id");
        String updatedBy = request.getParameter("updateBy");
        String content = request.getParameter("content");
        
        boolean update = updateDAO.editUpdate(new Update(updateid, content, updatedBy));
    
        if(update){
            RequestDispatcher rd = request.getRequestDispatcher("/update/list");
            rd.forward(request, response);
        }
    }
    
    private void deleteUpdate(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        
        int id = Integer.parseInt(request.getParameter("update_id"));
        
        updateDAO.deleteUpdate(id);
        RequestDispatcher rd = request.getRequestDispatcher("/update/list");
        rd.forward(request, response);
    }
    
}
