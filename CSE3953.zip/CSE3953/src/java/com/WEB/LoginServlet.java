package com.WEB;

import com.DAO.PatientDAO;
import com.DAO.UserDAO;
import com.Model.Patient;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login/*")
public class LoginServlet extends HttpServlet {

    private UserDAO userDAO;
    private PatientDAO patientDAO;

    public void init() {
        userDAO = new UserDAO();
        patientDAO = new PatientDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getPathInfo();

        switch (action) {
            case "/new":
                showLoginForm(request, response);
                break;
                
            case "/login":
                loginSuccessful(request, response);
                break;
                
            case "/create":
                showRegisterForm(request, response);
                break;
                
            case "/register":           
                try {
                registerPatient(request, response);
            } catch (SQLException ex) {
                Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
            break;
            
            case "/logout":
                logout(request, response);
                break;
        }
    }

    private void showLoginForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
        rd.forward(request, response);

    }

    private void loginSuccessful(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String userType = request.getParameter("user_type");

        // Logging the received username and password
        System.out.println("Username: " + username);
        System.out.println("Password: " + password);

        // Validating user according to user type
        if (userDAO.isUserValid(username, password, userType)) {

            // Get session object
            HttpSession session = request.getSession();

            // Set session attributes
            session.setAttribute("username", username);
            session.setAttribute("userType", userType);

            if (userType.equalsIgnoreCase("patient")) {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Patient Login Successful!');");
                out.println("window.location.href = '" + request.getContextPath() + "/patient/home';");
                out.println("</script>");

            } else if (userType.equalsIgnoreCase("staff")) {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Staff Login Successful!');");
                out.println("window.location.href = '" + request.getContextPath() + "/staff/home';");
                out.println("</script>");

            } else if (userType.equalsIgnoreCase("doctor")) {
                out.println("<script type=\"text/javascript\">");
                out.println("alert('Doctor Login Successful!');");
                out.println("window.location.href = '" + request.getContextPath() + "/doctor/home';");
                out.println("</script>");
            }
        } else {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Wrong Username or Password');");
            out.println("window.history.back();");
            out.println("</script>");
        }
    }

    private void showRegisterForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
        rd.forward(request, response);

    }

    private void registerPatient(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        PrintWriter out = response.getWriter();

        String full_name = request.getParameter("full_name");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String icnumber = request.getParameter("icnumber");
        String email = request.getParameter("email");
        String phonenumber = request.getParameter("phone_number");
        String gender = request.getParameter("gender");

        Patient newPatient = new Patient(username, password, full_name, icnumber, email, gender, phonenumber);

        if (userDAO.isUsernameTaken(username)) {
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Username is Taken!');");
            out.println("window.location.href = '" + request.getContextPath() + "/login/create';");
            out.println("</script>");

        } else {
            patientDAO.insertPatient(newPatient);
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Registered Successfully!');");
            out.println("window.location.href = '" + request.getContextPath() + "/login/new';");
            out.println("</script>");
        }
    }

    private void logout(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        HttpSession session = request.getSession();
        session.invalidate(); // Clear all session attributes and invalidate the session
        response.sendRedirect(request.getContextPath() + "/login/new");
    }
}
