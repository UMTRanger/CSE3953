package com.WEB;

import com.DAO.AppointmentDAO;
import com.DAO.DoctorDAO;
import com.DAO.UpdateDAO;
import com.Model.Appointment;
import com.Model.Update;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/doctor/*")
public class DoctorServlet extends HttpServlet {

    private DoctorDAO doctorDAO;
    private UpdateDAO updateDAO;
    private AppointmentDAO appointmentDAO;

    public void init() {
        doctorDAO = new DoctorDAO();
        updateDAO = new UpdateDAO();
        appointmentDAO = new AppointmentDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);

    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/home":
                    loginDoctor(request, response);
                    break;
                    
                case "/apply":
                    leaveForm(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);

        }
    }
    
    private void loginDoctor(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException,ServletException{
        //Loading list of updates
        List<Update> listUpdate = updateDAO.selectAllUpdates();
        request.setAttribute("listUpdate", listUpdate);
        
        //Creating a session
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String userType = (String) session.getAttribute("userType");
        
        if(userType.equalsIgnoreCase("doctor")){
            System.out.println(username);
            Appointment upcomingAppointment = appointmentDAO.selectUpcomingAppointmentByDoctorUsername(username);
            request.setAttribute("upcomingAppointment", upcomingAppointment);
        }
        
        RequestDispatcher rd= request.getRequestDispatcher("/doctor.jsp");
        rd.forward(request, response);
    }
    
    private void leaveForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException,ServletException{
        RequestDispatcher rd= request.getRequestDispatcher("/leaveForm.jsp");
        rd.forward(request, response);
    }
    
}
