package com.WEB;

import com.DAO.AppointmentDAO;
import com.DAO.RecordDAO;
import com.Model.Appointment;
import com.Model.PatientRecord;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/record/*")
public class RecordServlet extends HttpServlet {

    private RecordDAO recordDAO;
    private AppointmentDAO appointmentDAO;

    public void init() {
        recordDAO = new RecordDAO();
        appointmentDAO = new AppointmentDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/review": 
                    recordForm(request, response);             
                    break;
                    
                case "/insert":
                    insertRecord(request, response);
                    break;
                    
                case "/list":
                    recordList(request, response);
                    break;
                    
                case "/edit":
                    updateForm(request, response);
                    break;
                    
                case "/update":
                    updateRecord(request, response);
                    break;
                    
                case "/delete":
                    deleteRecord(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
            
        } catch (ParseException ex) {
            Logger.getLogger(RecordServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void recordForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        int appointment_id = Integer.parseInt(request.getParameter("appointment_id"));
        
        Appointment appointment = appointmentDAO.selectAppointment(appointment_id);
        request.setAttribute("appointment", appointment);
        
        RequestDispatcher rd = request.getRequestDispatcher("/recordForm.jsp");
        rd.forward(request, response);
    }
    
    private void insertRecord(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException, ParseException {
        
        int appointment_id = Integer.parseInt(request.getParameter("appointment_id"));
        
        //Getting records from the form
        String patient_username = request.getParameter("patient_username");
        String appointment_date = request.getParameter("appointment_date");
        String diagnosis = request.getParameter("diagnosis");
        String treatment = request.getParameter("treatment");
        String prescription = request.getParameter("prescription");
        String labresult = request.getParameter("labresult");
        String doctor_username = request.getParameter("doctor_username");
    
        PatientRecord record = new PatientRecord(patient_username, appointment_date,diagnosis,treatment,prescription,labresult,doctor_username);
        appointmentDAO.deleteAppointment(appointment_id);
        
        recordDAO.insertRecord(record);
        RequestDispatcher rd = request.getRequestDispatcher("/record/list");
        rd.forward(request, response);
    }
    
    private void recordList(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException, ParseException {
        List<PatientRecord> listRecord = recordDAO.selectAllRecord();
        request.setAttribute("listRecord", listRecord);
        
        RequestDispatcher rd = request.getRequestDispatcher("/record.jsp");
        rd.forward(request, response);
    }
    
    private void updateForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("record_id"));
        PatientRecord existingRecord = recordDAO.selectRecord(id);
        
        RequestDispatcher rd = request.getRequestDispatcher("/updateRecord.jsp");
        request.setAttribute("record", existingRecord);
        rd.forward(request, response);
    }
    
    private void updateRecord(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {

        int record_id = Integer.parseInt(request.getParameter("record_id"));
        String patient_username = request.getParameter("patient_username");
        String appointment_date = request.getParameter("appointment_date");
        String diagnosis = request.getParameter("diagnosis");
        String treatment = request.getParameter("treatment");
        String prescription = request.getParameter("prescription");
        String labresult = request.getParameter("labresult");
        String doctor_username = request.getParameter("doctor_username");

        boolean update = recordDAO.updateRecord(new PatientRecord(record_id, patient_username, appointment_date,diagnosis,treatment,prescription,labresult,doctor_username));

        if (update) {
            RequestDispatcher rd = request.getRequestDispatcher("/record/list");
            rd.forward(request, response);
        }
    }
    
    private void deleteRecord(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("record_id"));
        recordDAO.deleteRecord(id);
        
        RequestDispatcher rd = request.getRequestDispatcher("/record/list");
        rd.forward(request, response);   
        
    }
}

