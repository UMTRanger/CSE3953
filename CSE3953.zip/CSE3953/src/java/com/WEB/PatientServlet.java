package com.WEB;

import com.DAO.AppointmentDAO;
import com.DAO.PatientDAO;
import com.DAO.UpdateDAO;
import com.Model.Appointment;
import com.Model.Patient;
import com.Model.Update;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/patient/*")
public class PatientServlet extends HttpServlet {

    private PatientDAO patientDAO;
    private AppointmentDAO appointmentDAO;
    private UpdateDAO updateDAO;

    public void init() {
        patientDAO = new PatientDAO();
        appointmentDAO = new AppointmentDAO();
        updateDAO = new UpdateDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/home":
                    loginPatient(request, response);
                    break;
                case "/delete":
                    deletePatient(request, response);
                    break;
                case "/profile":
                    patientProfile(request, response);
                    break;
                case "/edit":
                    updateForm(request, response);
                    break;
                case "/update":
                    updatePatient(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);

        }
    }

    private void loginPatient(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        //Loading list of updates
        List<Update> listUpdate = updateDAO.selectAllUpdates();
        request.setAttribute("listUpdate", listUpdate);
        
        RequestDispatcher rd = request.getRequestDispatcher("/patient.jsp");
        rd.forward(request, response);
    }

    private void patientProfile(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        //Creating a session
        HttpSession session = request.getSession();

        //Retrieve username
        String username = (String) session.getAttribute("username");

        //Check if the user is logged on
        if (username == null) {
            response.sendRedirect("/login/new");
            return;
        }
        Patient patient = patientDAO.selectPatient(username);

        session.setAttribute("patient", patient);

        RequestDispatcher rd = request.getRequestDispatcher("/account.jsp");
        rd.forward(request, response);
    }

    private void updateForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        //Creating a session
        HttpSession session = request.getSession();

        //Retrieve username
        String username = (String) session.getAttribute("username");
        Patient existingPatient = patientDAO.selectPatient(username);

        RequestDispatcher rd = request.getRequestDispatcher("/updatePatient.jsp");
        request.setAttribute("patient", existingPatient);
        rd.forward(request, response);
    }

    private void updatePatient(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {

        String username = request.getParameter("username");
        String name = request.getParameter("full_name");
        String password = request.getParameter("password");
        String icnumber = request.getParameter("icnumber");
        String email = request.getParameter("email");
        String gender = request.getParameter("gender");
        String phonenumber = request.getParameter("phone_number");

        boolean update = patientDAO.updatePatient(new Patient(username, password, name, icnumber, email, gender, phonenumber));

        if (update) {
            RequestDispatcher rd = request.getRequestDispatcher("/patient/profile");
            rd.forward(request, response);
        }
    }

    private void deletePatient(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        patientDAO.deletePatient(username);
        RequestDispatcher rd = request.getRequestDispatcher("/login/new");
        rd.forward(request, response);   
        
    }

    
    
    
    //    //List out patients in the clinic
//    private void listPatient(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
//        List<Patient> listPatient = patientDAO.selectAllPatient();
//        request.setAttribute("listPatient", listPatient);
//        RequestDispatcher rd = request.getRequestDispatcher("");        //TO BE UPDATED
//        rd.forward(request, response);
//    }
}
