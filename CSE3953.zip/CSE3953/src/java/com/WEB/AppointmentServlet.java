package com.WEB;

import com.DAO.AppointmentDAO;
import com.DAO.DoctorDAO;
import com.DAO.PatientDAO;
import com.Model.Appointment;
import com.Model.Doctor;
import com.Model.Patient;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/appointment/*")
public class AppointmentServlet extends HttpServlet {

    private PatientDAO patientDAO;
    private AppointmentDAO appointmentDAO;
    private DoctorDAO doctorDAO;

    public void init() {
        patientDAO = new PatientDAO();
        appointmentDAO = new AppointmentDAO();
        doctorDAO = new DoctorDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/view":
                    viewAppointment(request, response);
                    break;

                case "/create":
                    appointmentForm(request, response);
                    break;

                case "/make":
                    makeAppointment(request, response);
                    break;

                case "/delete":
                    deleteAppointment(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);

        } catch (ParseException ex) {
            Logger.getLogger(AppointmentServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void viewAppointment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        //Creating a session
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String userType = (String) session.getAttribute("userType");
        
        System.out.println(username);
        if (userType.equalsIgnoreCase("patient")) {
            System.out.println(username);
            Appointment upcomingAppointment = appointmentDAO.selectUpcomingAppointmentByUsername(username);
            request.setAttribute("upcomingAppointment", upcomingAppointment);
            
            List<Appointment> listAppointment = appointmentDAO.selectAllAppointmentByUsername(username);            
            request.setAttribute("listAppointment", listAppointment);
            
        }else if(userType.equalsIgnoreCase("doctor")){
            System.out.println(username);
            Appointment upcomingAppointment = appointmentDAO.selectUpcomingAppointmentByDoctorUsername(username);
            request.setAttribute("upcomingAppointment", upcomingAppointment);
            List<Appointment> listAppointment = appointmentDAO.selectAllAppointmentByDoctorUsername(username);
            
            request.setAttribute("listAppointment", listAppointment);
        }

        RequestDispatcher rd = request.getRequestDispatcher("/viewAppointment.jsp");
        rd.forward(request, response);
    }

    private void appointmentForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        //Creating a session
        HttpSession session = request.getSession();

        //Retrieve username
        String username = (String) session.getAttribute("username");
        Patient existingPatient = patientDAO.selectPatient(username);

        //List of doctors
        List<Doctor> doctors = doctorDAO.selectAllDoctors();

        RequestDispatcher rd = request.getRequestDispatcher("/makeAppointment.jsp");
        request.setAttribute("patient", existingPatient);
        request.setAttribute("doctors", doctors);
        rd.forward(request, response);
    }

    private void makeAppointment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException, ParseException {
        PrintWriter out = response.getWriter();

        String patient_username = request.getParameter("username");
        String appointment_date = request.getParameter("date");
        String appointment_time = request.getParameter("time");
        String doctor = request.getParameter("doctor");

        Appointment appointment = new Appointment(patient_username, appointment_date, appointment_time, doctor);

        appointmentDAO.insertAppointment(appointment);
        out.println("<script type=\"text/javascript\">");
        out.println("alert('Appointment Made!');");
        out.println("window.location.href = '" + request.getContextPath() + "/appointment/view';");
        out.println("</script>");
    }

    private void deleteAppointment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {

        int id = Integer.parseInt(request.getParameter("appointment_id"));

        appointmentDAO.deleteAppointment(id);
        RequestDispatcher rd = request.getRequestDispatcher("/appointment/view");
        rd.forward(request, response);
    }
}
