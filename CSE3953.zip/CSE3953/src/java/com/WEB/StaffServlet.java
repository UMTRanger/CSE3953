package com.WEB;


import com.DAO.AppointmentDAO;
import com.DAO.AvailabilityDAO;
import com.DAO.ClinicStaffDAO;
import com.DAO.DoctorDAO;
import com.DAO.PatientDAO;
import com.DAO.UpdateDAO;
import com.Model.Appointment;
import com.Model.Availability;
import com.Model.ClinicStaff;
import com.Model.Doctor;
import com.Model.Patient;
import com.Model.Update;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/staff/*")
public class StaffServlet extends HttpServlet {

        private ClinicStaffDAO staffDAO;
        private UpdateDAO updateDAO;
        private AppointmentDAO appointmentDAO;
        private AvailabilityDAO availabilityDAO;
        private PatientDAO patientDAO;
        private DoctorDAO doctorDAO;
        
public void init() {
        staffDAO = new ClinicStaffDAO();
        updateDAO = new UpdateDAO();
        availabilityDAO = new AvailabilityDAO();
        patientDAO = new PatientDAO();
        doctorDAO = new DoctorDAO();
        appointmentDAO = new AppointmentDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getPathInfo();

        try {
            switch (action) {
                case "/home":
                    loginStaff(request, response);
                    break;
                    
                case "/patientList":
                    patientList(request, response);
                    break;
                    
                case "/editPatient":
                    updatePatientForm(request, response);
                    break;
                    
                case "/updatePatient":
                    updatePatient(request, response);
                    break;
                    
                case "/deletePatient":
                    deletePatient(request, response);
                    break;
                    
                case "/doctorList":
                    doctorList(request, response);
                    break;
                    
                case "/createDoctor":
                    createDoctorForm (request, response);
                    break;
                    
                case "/insertDoctor":
                    insertDoctor(request, response);
                    break;
                    
                case "/editDoctor":
                    updateDoctorForm(request, response);
                    break;
                    
                case "/deleteDoctor":
                    deleteDoctor(request, response);
                    break;
                    
                case "/updateDoctor":
                    updateDoctor(request, response);
                    break;
                    
                case "/appointment":
                    appointmentList(request, response);
                    break;
                    
                case "/editAppointment":
                    updateAppointmentForm(request, response);
                    break;
                    
                case "/updateAppointment":
                    updateAppointment(request, response);
                    break;
                    
                case "/deleteAppointment":
                    deleteAppointment(request, response);
                    break;
                    
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);

        }
    }
    
    private void loginStaff(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        //Loading list of unavailable doctors
        List<Availability> listAvailable = availabilityDAO.selectAllDate();
        request.setAttribute("listAvailable", listAvailable);
        
        RequestDispatcher rd = request.getRequestDispatcher("/staff.jsp");
        rd.forward(request, response);
    }
    
    //-------------------   Manage Appointment -----------------------
    
    private void appointmentList(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        List<Appointment> listAppointment = appointmentDAO.selectAllAppointment();
        request.setAttribute("listAppointment", listAppointment);
        
        RequestDispatcher rd = request.getRequestDispatcher("/manageAppointment.jsp");
        rd.forward(request, response);
    }
    
    private void updateAppointmentForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        
        //List of doctors
        List<Doctor> doctors = doctorDAO.selectAllDoctors();
        
        int appointment_id = Integer.parseInt(request.getParameter("appointment_id"));
        Appointment existingAppointment = appointmentDAO.selectAppointment(appointment_id);

        RequestDispatcher rd = request.getRequestDispatcher("/staffUpdateAppointment.jsp");
        request.setAttribute("appointment", existingAppointment);
        request.setAttribute("doctors", doctors);
        rd.forward(request, response);
    }
       
    private void updateAppointment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {

        int id = Integer.parseInt(request.getParameter("appointment_id"));
        String username = request.getParameter("username");
        String date = request.getParameter("date");
        String time = request.getParameter("time");
        String doctor = request.getParameter("doctor");

        boolean update = appointmentDAO.updatePatient(new Appointment(id, username, date, time, doctor));

        if (update) {
            RequestDispatcher rd = request.getRequestDispatcher("/staff/appointment");
            rd.forward(request, response);
        }
    }
    
    private void deleteAppointment(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("appointment_id"));
        
        appointmentDAO.deleteAppointment(id);
        RequestDispatcher rd = request.getRequestDispatcher("/staff/appointment");
        rd.forward(request, response);   
        
    }
    
    
    //-------------------   Manage Doctor -----------------------
    
    private void doctorList(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException{
        //Loading list of doctors
        List<Doctor> listDoctor = doctorDAO.selectAllDoctors();
        request.setAttribute("listDoctor", listDoctor);
        
        RequestDispatcher rd = request.getRequestDispatcher("/manageDoctor.jsp");
        rd.forward(request, response);
    }

    private void createDoctorForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher("/createDoctor.jsp");
        rd.forward(request, response);

    }
    
    private void insertDoctor(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String phonenumber = request.getParameter("phonenumber");
        String specialty = request.getParameter("specialty");
        
        Doctor doctor = new Doctor(username, password, name, phonenumber, specialty);
        
        doctorDAO.insertDoctor(doctor);
        
        RequestDispatcher rd = request.getRequestDispatcher("/staff/doctorList");
        rd.forward(request, response);
    }
        
    private void updateDoctorForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        
        String username = request.getParameter("doctor_username");
        Doctor existingDoctor = doctorDAO.selectDoctor(username);

        RequestDispatcher rd = request.getRequestDispatcher("/updateDoctor.jsp");
        request.setAttribute("doctor", existingDoctor);
        rd.forward(request, response);
    }
    
    private void updateDoctor(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String phonenumber = request.getParameter("phonenumber");
        String specialty = request.getParameter("specialty");

        boolean update = doctorDAO.updateDoctor(new Doctor(username, password, name, phonenumber, specialty));

        if (update) {
            RequestDispatcher rd = request.getRequestDispatcher("/staff/doctorList");
            rd.forward(request, response);
        }
    }
    
    private void deleteDoctor(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        String username = request.getParameter("doctor_username");
        doctorDAO.deleteDoctor(username);
        RequestDispatcher rd = request.getRequestDispatcher("/staff/doctorList");
        rd.forward(request, response);   
        
    }
    
    
    //-------------------   Manage Patient -----------------------
    
    private void patientList(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException{
        //Loading list of patients
        List<Patient> listPatient = patientDAO.selectAllPatient();
        request.setAttribute("listPatient", listPatient);
        
        RequestDispatcher rd = request.getRequestDispatcher("/managePatient.jsp");
        rd.forward(request, response);
    }
    
    private void updatePatientForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        
        String username = request.getParameter("patient_username");
        Patient existingPatient = patientDAO.selectPatient(username);

        RequestDispatcher rd = request.getRequestDispatcher("/staffUpdatePatient.jsp");
        request.setAttribute("patient", existingPatient);
        rd.forward(request, response);
    }
    
    private void updatePatient(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {

        String username = request.getParameter("username");
        String name = request.getParameter("full_name");
        String password = request.getParameter("password");
        String icnumber = request.getParameter("icnumber");
        String email = request.getParameter("email");
        String gender = request.getParameter("gender");
        String phonenumber = request.getParameter("phone_number");

        boolean update = patientDAO.updatePatient(new Patient(username, password, name, icnumber, email, gender, phonenumber));

        if (update) {
            RequestDispatcher rd = request.getRequestDispatcher("/staff/patientList");
            rd.forward(request, response);
        }
    }
    
    private void deletePatient(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        String username = request.getParameter("patient_username");
        patientDAO.deletePatient(username);
        RequestDispatcher rd = request.getRequestDispatcher("/staff/patientList");
        rd.forward(request, response);   
        
    }
    
}
