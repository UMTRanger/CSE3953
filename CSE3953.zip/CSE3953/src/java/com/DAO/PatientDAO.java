package com.DAO;

import com.Model.Patient;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {

    private static final String jdbcURL = "jdbc:mysql://localhost:3306/cse3953_clinic";
    private static final String jdbcUsername = "root";
    private static final String jdbcPassword = "admin";

    private static final String INSERT_PATIENT = "INSERT INTO patient (p_username, p_password, p_name, p_icnumber, p_email, p_gender, p_phonenumber) VALUES (?,?,?,?,?,?,?)";
    private final String SELECT_PATIENT_BY_ID = "SELECT p_password, p_name, p_icnumber, p_email, p_gender, p_phonenumber FROM patient WHERE p_username=?";
    private final String SELECT_ALL_PATIENT = "SELECT * FROM patient";
    private final String DELETE_PATIENT = "DELETE FROM patient WHERE p_username=?";
    private final String UPDATE_PATIENT = "UPDATE patient SET p_password=?,p_name=?,p_icnumber=?,p_email=?,p_gender=?,p_phonenumber=? WHERE p_username=?";

    public PatientDAO() {
    }

    protected static Connection getConnection() throws SQLException {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Connection Established");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Unable to get connection");
        }

        return con;
    }

    public void insertPatient(Patient patient) throws SQLException {
        System.out.println(INSERT_PATIENT);

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(INSERT_PATIENT)) {
            ps.setString(1, patient.getPatient_username());
            ps.setString(2, patient.getPatient_password());
            ps.setString(3, patient.getPatient_name());
            ps.setString(4, patient.getPatient_icnumber());
            ps.setString(5, patient.getPatient_email());
            ps.setString(6, patient.getPatient_gender());
            ps.setString(7, patient.getPatient_phonenumber());
            System.out.println(ps);
            ps.executeUpdate();

        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Patient selectPatient(String patient_username) throws SQLException {
        Patient patient = null;

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_PATIENT_BY_ID)) {
            ps.setString(1, patient_username);
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String password = rs.getString("p_password");
                String name = rs.getString("p_name");
                String icnumber = rs.getString("p_icnumber");
                String email = rs.getString("p_email");
                String gender = rs.getString("p_gender");
                String phonenumber = rs.getString("p_phonenumber");
                patient = new Patient(patient_username, password, name, icnumber, email,  gender, phonenumber);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return patient;
    }

    public List<Patient> selectAllPatient() throws SQLException {
        List<Patient> patient = new ArrayList<>();

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_ALL_PATIENT);) {
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String username = rs.getString("p_username");
                String password = rs.getString("p_password");
                String name = rs.getString("p_name");
                String icnumber = rs.getString("p_icnumber");
                String email = rs.getString("p_email");
                String gender = rs.getString("p_gender");
                String phonenumber = rs.getString("p_phonenumber");
                patient.add(new Patient(username, password, name, icnumber, email, gender, phonenumber));
            }
        }

        return patient;
    }

    public boolean deletePatient(String username) throws SQLException {
        boolean patient_deleted;

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(DELETE_PATIENT);) {
            ps.setString(1, username);
            patient_deleted = ps.executeUpdate() > 0;
        }       

        return patient_deleted;
    }

    public boolean updatePatient(Patient patient) throws SQLException {
        boolean rowUpdated = false;
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(UPDATE_PATIENT);) {

            ps.setString(1, patient.getPatient_password());
            ps.setString(2, patient.getPatient_name());
            ps.setString(3, patient.getPatient_icnumber());
            ps.setString(4, patient.getPatient_email());
            ps.setString(5, patient.getPatient_gender());
            ps.setString(6, patient.getPatient_phonenumber());
            ps.setString(7, patient.getPatient_username());

            System.out.println("Executing update: " + ps);

            rowUpdated = ps.executeUpdate() > 0;


        } catch (SQLException e) {
            printSQLException(e);
        }
        return rowUpdated;
    }

    private static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
