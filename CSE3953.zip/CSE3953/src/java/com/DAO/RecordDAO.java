package com.DAO;

import com.Model.PatientRecord;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RecordDAO {
    
    private static final String jdbcURL = "jdbc:mysql://localhost:3306/cse3953_clinic";
    private static final String jdbcUsername = "root";
    private static final String jdbcPassword = "admin";
    
    private final String INSERT_RECORD = "INSERT INTO record (p_username, a_date, diagnosis, treatment, prescription, labResult, d_username) VALUES (?,?,?,?,?,?,?)";
    private final String SELECT_RECORD = "SELECT p_username, a_date, diagnosis, treatment, prescription, labResult, d_username FROM record WHERE r_id=?";
    private final String SELECT_ALL_RECORD = "SELECT * FROM record";
    private final String DELETE_RECORD = "DELETE FROM record WHERE r_id=?";
    private final String UPDATE_RECORD = "UPDATE record SET p_username=?, a_date=?, diagnosis=?, treatment=?, prescription=?, labResult=?, d_username=? WHERE r_id=?";
    
    public RecordDAO(){
        
    }
    
    protected static Connection getConnection() throws SQLException {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Connection Established");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Unable to get connection");
        }

        return con;
    }
    
    public void insertRecord(PatientRecord record) throws SQLException{
        System.out.println(INSERT_RECORD);
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(INSERT_RECORD)) {
            ps.setString(1, record.getPatient_username());
            ps.setString(2,record.getAppointment_date());
            ps.setString(3, record.getDiagnosis());
            ps.setString(4, record.getTreatment());
            ps.setString(5, record.getPrescription());
            ps.setString(6, record.getLabresult());
            ps.setString(7, record.getDoctor_username());
            
            System.out.println(ps);
            ps.executeUpdate();

        } catch (SQLException e) {
            printSQLException(e);
        }
    }
    
    public PatientRecord selectRecord(int r_id) throws SQLException {
        PatientRecord record = null;

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_RECORD)) {
            ps.setInt(1, r_id);
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String patient_username = rs.getString("p_username");
                String appointment_date = rs.getString("a_date");
                String diagnosis = rs.getString("diagnosis");
                String treatment = rs.getString("treatment");
                String prescription = rs.getString("prescription");
                String labResult = rs.getString("labResult");
                String doctor_username = rs.getString("d_username");
                record = new PatientRecord(r_id, patient_username, appointment_date, diagnosis, treatment, prescription,  labResult, doctor_username);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return record;
    }
    
    public List<PatientRecord> selectAllRecord() throws SQLException {
        List<PatientRecord> record = new ArrayList<>();

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_ALL_RECORD);) {
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int r_id = rs.getInt("r_id");
                String patient_username = rs.getString("p_username");
                String appointment_date = rs.getString("a_date");
                String diagnosis = rs.getString("diagnosis");
                String treatment = rs.getString("treatment");
                String prescription = rs.getString("prescription");
                String labResult = rs.getString("labResult");
                String doctor_username = rs.getString("d_username");
                record.add(new PatientRecord(r_id, patient_username, appointment_date, diagnosis, treatment, prescription,  labResult, doctor_username));
            }
        }

        return record;
    }
    
    public boolean deleteRecord(int id) throws SQLException {
        boolean patient_deleted;

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(DELETE_RECORD);) {
            ps.setInt(1, id);
            patient_deleted = ps.executeUpdate() > 0;
        }       

        return patient_deleted;
    }
    
    public boolean updateRecord(PatientRecord record) throws SQLException {
        boolean rowUpdated = false;
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(UPDATE_RECORD);) {

            ps.setString(1, record.getPatient_username());
            ps.setString(2, record.getAppointment_date());
            ps.setString(3, record.getDiagnosis());
            ps.setString(4, record.getTreatment());
            ps.setString(5, record.getPrescription());
            ps.setString(6, record.getLabresult());
            ps.setString(7,record.getDoctor_username());
            ps.setInt(8, record.getRecord_id());

            System.out.println("Executing update: " + ps);

            rowUpdated = ps.executeUpdate() > 0;

        } catch (SQLException e) {
            printSQLException(e);
        }
        return rowUpdated;
    }
    
    private static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
