package com.DAO;

import com.Model.Appointment;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDAO {

    private static final String jdbcURL = "jdbc:mysql://localhost:3306/cse3953_clinic";
    private static final String jdbcUsername = "root";
    private static final String jdbcPassword = "admin";

    private final String INSERT_APPOINTMENT = "INSERT INTO appointment (p_username, a_date, a_time, d_username) VALUES (?,?,?,?)";
    private final String SELECT_APPOINTMENT_BY_ID = "SELECT * FROM appointment WHERE appointment_id=?";
    private final String SELECT_ALL_APPOINTMENT_BY_USERNAME = "SELECT * FROM appointment WHERE p_username=?";
    private final String SELECT_ALL_APPOINTMENT_BY_DOCTOR_USERNAME = "SELECT * FROM appointment WHERE d_username=?";
    private final String SELECT_ALL_APPOINTMENT = "SELECT * FROM appointment";
    private final String DELETE_APPOINTMENT = "DELETE FROM appointment WHERE appointment_id=?";
    private final String UPDATE_APPOINTMENT = "UPDATE appointment SET p_username=?, a_date=?,a_time=?,d_username=? WHERE appointment_id=?";
    private final String SELECT_APPOINTMENT_BY_ID_UPCOMING = "SELECT * FROM appointment where p_username=? ORDER BY appointment_id ASC LIMIT 1";
    private final String SELECT_APPOINTMENT_BY_DOCTOR_ID_UPCOMING = "SELECT * FROM appointment where d_username=? ORDER BY appointment_id ASC LIMIT 1";

    public AppointmentDAO() {
    }

    protected static Connection getConnection() throws SQLException {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Connection Established");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Unable to get connection");
        }

        return con;
    }

    public void insertAppointment(Appointment appointment) throws SQLException {
        System.out.println(INSERT_APPOINTMENT);

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(INSERT_APPOINTMENT)) {
            ps.setString(1, appointment.getPatient_username());
            ps.setString(2, appointment.getAppointmentDate());
            ps.setString(3, appointment.getAppointmentTime());
            ps.setString(4, appointment.getDoctor_id());

            System.out.println(ps);
            ps.executeUpdate();

        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Appointment selectAppointment(int id) throws SQLException {
        Appointment appointment = null;

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_APPOINTMENT_BY_ID)) {
            ps.setInt(1, id);
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String patient_username = rs.getString("p_username");
                String appointment_date = rs.getString("a_date");
                String appointment_time = rs.getString("a_time");
                String doctor = rs.getString("d_username");
                appointment = new Appointment(id, patient_username, appointment_date, appointment_time, doctor);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return appointment;
    }
    
    public Appointment selectUpcomingAppointmentByUsername(String username) throws SQLException{
        Appointment appointment = null;
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_APPOINTMENT_BY_ID_UPCOMING)) {
            ps.setString(1, username);
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointment_id = rs.getInt("appointment_id");
                String appointment_date = rs.getString("a_date");
                String appointment_time = rs.getString("a_time");
                String doctor = rs.getString("d_username");
                appointment = new Appointment(appointment_id, username, appointment_date, appointment_time, doctor);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return appointment;
    }
    
    public Appointment selectUpcomingAppointmentByDoctorUsername(String username) throws SQLException{
        Appointment appointment = null;
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_APPOINTMENT_BY_DOCTOR_ID_UPCOMING)) {
            ps.setString(1, username);
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointment_id = rs.getInt("appointment_id");
                String appointment_date = rs.getString("a_date");
                String appointment_time = rs.getString("a_time");
                String doctor = rs.getString("d_username");
                appointment = new Appointment(appointment_id, username, appointment_date, appointment_time, doctor);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return appointment;
    }

    public List<Appointment> selectAllAppointment() throws SQLException {
        List<Appointment> appointment = new ArrayList<>();

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_ALL_APPOINTMENT);) {
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointment_id = rs.getInt("appointment_id");
                String patient_username = rs.getString("p_username");
                String appointment_date = rs.getString("a_date");
                String appointment_time = rs.getString("a_time");
                String doctor = rs.getString("d_username");
                appointment.add(new Appointment(appointment_id, patient_username, appointment_date, appointment_time, doctor));
            }
        }

        return appointment;
    }

    public List<Appointment> selectAllAppointmentByUsername(String username) throws SQLException {
        List<Appointment> appointment = new ArrayList<>();

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_ALL_APPOINTMENT_BY_USERNAME);) {
            ps.setString(1, username);
            System.out.println(ps);
            
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointment_id = rs.getInt("appointment_id");
                String patient_username = rs.getString("p_username");
                String appointment_date = rs.getString("a_date");
                String appointment_time = rs.getString("a_time");
                String doctor = rs.getString("d_username");
                appointment.add(new Appointment(appointment_id, patient_username, appointment_date, appointment_time, doctor));
            }
        }

        return appointment;
    }
    
    public List<Appointment> selectAllAppointmentByDoctorUsername(String username) throws SQLException {
        List<Appointment> appointment = new ArrayList<>();

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_ALL_APPOINTMENT_BY_DOCTOR_USERNAME);) {
            ps.setString(1, username);
            System.out.println(ps);
            
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int appointment_id = rs.getInt("appointment_id");
                String patient_username = rs.getString("p_username");
                String appointment_date = rs.getString("a_date");
                String appointment_time = rs.getString("a_time");
                String doctor = rs.getString("d_username");
                appointment.add(new Appointment(appointment_id, patient_username, appointment_date, appointment_time, doctor));
            }
        }

        return appointment;
    }

    public boolean deleteAppointment(int id) throws SQLException {
        boolean appointment_deleted;

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(DELETE_APPOINTMENT);) {
            ps.setInt(1, id);
            appointment_deleted = ps.executeUpdate() > 0;
        }

        return appointment_deleted;
    }

    public boolean updatePatient(Appointment appointment) throws SQLException {
        boolean rowUpdated = false;
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(UPDATE_APPOINTMENT);) {

            ps.setString(1, appointment.getPatient_username());
            ps.setString(2, appointment.getAppointmentDate());
            ps.setString(3, appointment.getAppointmentTime());
            ps.setString(4, appointment.getDoctor_id());
            ps.setInt(5, appointment.getAppointment_id());

            System.out.println("Executing update: " + ps);

            rowUpdated = ps.executeUpdate() > 0;

        } catch (SQLException e) {
            printSQLException(e);
        }
        return rowUpdated;
    }

    private static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
