package com.DAO;

import com.Model.Update;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UpdateDAO {
    
    private static final String jdbcURL = "jdbc:mysql://localhost:3306/cse3953_clinic";
    private static final String jdbcUsername = "root";
    private static final String jdbcPassword = "admin";
    
    private final String INSERT_UPDATE = "INSERT INTO clinicupdate(update_content, cs_username) VALUES (?,?)";
    private final String SELECT_UPDATE = "SELECT * FROM clinicupdate where update_id=?";
    private final String DELETE_UPDATE = "DELETE FROM clinicupdate WHERE update_id=?";
    private final String EDIT_UPDATE = "UPDATE clinicupdate SET update_content=?, cs_username=? WHERE update_id=?";
    private final String SELECT_ALL_UPDATES = "SELECT * FROM clinicupdate";
    
    public UpdateDAO(){        
    }
    
    protected static Connection getConnection() throws SQLException {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Connection Established");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Unable to get connection");
        }

        return con;
    }
    
    public void insertUpdate(Update update) throws SQLException{
        System.out.println(INSERT_UPDATE);

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(INSERT_UPDATE)) {
            ps.setString(1, update.getUpdateContent());
            ps.setString(2, update.getUpdatedBy());
            
            System.out.println(ps);
            ps.executeUpdate();

        } catch (SQLException e) {
            printSQLException(e);
        }
    }
    
    public Update selectPatient(int id) throws SQLException {
        Update update = null;

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_UPDATE)) {
            ps.setInt(1, id);
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String updateid = rs.getString("update_id");
                String updateContent = rs.getString("update_content");
                String cs_username = rs.getString("cs_username");
                
                update = new Update(updateid, updateContent, cs_username);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return update;
    }
        
    public boolean deleteUpdate(int update_id) throws SQLException{
        boolean update_deleted;
        
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(DELETE_UPDATE);) {
            ps.setInt(1, update_id);
            update_deleted = ps.executeUpdate() > 0;
        }       

        return update_deleted;
    }
    
    public boolean editUpdate(Update update) throws SQLException{
        boolean rowUpdated = false;
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(EDIT_UPDATE);) {

            ps.setString(1, update.getUpdateContent());
            ps.setString(2, update.getUpdatedBy());
            ps.setInt(3, Integer.parseInt(update.getUpdateid()));

            System.out.println("Executing update: " + ps);

            rowUpdated = ps.executeUpdate() > 0;

        } catch (SQLException e) {
            printSQLException(e);
        }
        
        return rowUpdated;
    }
    
    public List<Update> selectAllUpdates() throws SQLException{
        List<Update> update = new ArrayList<>();
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_ALL_UPDATES);) {
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String updateID = rs.getString("update_id");
                String updateContent = rs.getString("update_content");
                String updatedBy = rs.getString("cs_username");
                
                update.add(new Update(updateID, updateContent, updatedBy));
            }
        }

        return update;
    }
    
    private static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
    
}
