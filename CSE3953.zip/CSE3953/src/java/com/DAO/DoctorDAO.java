/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DAO;

import com.Model.Doctor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO {

    private static final String jdbcURL = "jdbc:mysql://localhost:3306/cse3953_clinic";
    private static final String jdbcUsername = "root";
    private static final String jdbcPassword = "admin";

    private final String INSERT_DOCTOR = "INSERT INTO doctor (d_username, d_password, d_name, d_phonenumber, specialty) VALUES (?,?,?,?,?)";
    private final String SELECT_DOCTOR = "SELECT d_password, d_name, d_phonenumber, specialty FROM doctor WHERE d_username=?";
    private final String SELECT_ALL_DOCTORS = "SELECT * FROM doctor";
    private final String DELETE_DOCTOR = "DELETE FROM doctor WHERE d_username=?";
    private final String UPDATE_DOCTOR = "UPDATE doctor SET d_password=?, d_name=?, d_phonenumber=?, specialty=? WHERE d_username=?";
    
    public DoctorDAO() {

    }

    protected static Connection getConnection() throws SQLException {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Connection Established");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Unable to get connection");
        }

        return con;
    }

    public void insertDoctor(Doctor doctor) throws SQLException{
        System.out.println(INSERT_DOCTOR);
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(INSERT_DOCTOR)) {
            ps.setString(1, doctor.getDoctor_username());
            ps.setString(2, doctor.getDoctor_password());
            ps.setString(3, doctor.getDoctor_name());
            ps.setString(4, doctor.getDoctor_phonenumber());
            ps.setString(5, doctor.getSpecialty());
            System.out.println(ps);
            ps.executeUpdate();

        } catch (SQLException e) {
            printSQLException(e);
        }
    }
    
    public boolean deleteDoctor(String username) throws SQLException{
        boolean doctor_deleted;
        
         try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(DELETE_DOCTOR);) {
            ps.setString(1, username);
            doctor_deleted = ps.executeUpdate() > 0;
        }   
        return doctor_deleted;
    }
    
    public boolean updateDoctor(Doctor doctor) throws SQLException {
        boolean rowUpdated = false;
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(UPDATE_DOCTOR);) {

            ps.setString(1, doctor.getDoctor_password());
            ps.setString(2, doctor.getDoctor_name());
            ps.setString(3, doctor.getDoctor_phonenumber());
            ps.setString(4, doctor.getSpecialty());
            ps.setString(5, doctor.getDoctor_username());

            System.out.println("Executing update: " + ps);

            rowUpdated = ps.executeUpdate() > 0;


        } catch (SQLException e) {
            printSQLException(e);
        }
        return rowUpdated;
    }
    
    public Doctor selectDoctor(String doctor_username) throws SQLException{
        Doctor doctor = null;
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_DOCTOR)) {
            ps.setString(1, doctor_username);
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String password = rs.getString("d_password");
                String name = rs.getString("d_name");
                String phonenumber = rs.getString("d_phonenumber");
                String specialty = rs.getString("specialty");
                doctor = new Doctor(doctor_username, password, name, phonenumber, specialty);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return doctor;
    }
    
    public List<Doctor> selectAllDoctors() throws SQLException {
        List<Doctor> doctor = new ArrayList<>();

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_ALL_DOCTORS);) {
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String username = rs.getString("d_username");
                String password = rs.getString("d_password");
                String name = rs.getString("d_name");
                String phonenumber = rs.getString("d_phonenumber");
                String specialty = rs.getString("specialty");
                doctor.add(new Doctor(username, password, name, phonenumber, specialty));
            }
        }
        
        return doctor;
    }
    
    private static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
