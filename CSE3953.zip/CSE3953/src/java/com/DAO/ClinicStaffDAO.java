package com.DAO;

import com.Model.ClinicStaff;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClinicStaffDAO {
    
    private static final String jdbcURL = "jdbc:mysql://localhost:3306/cse3953_clinic";
    private static final String jdbcUsername = "root";
    private static final String jdbcPassword = "admin";

    private final String INSERT_STAFF = "INSERT INTO clinicstaff (cs_username, cs_password, cs_name, cs_phonenumber) VALUES (?,?,?,?)";
    private final String SELECT_STAFF_BY_USERNAME = "SELECT cs_password, cs_name, cs_phonenumber FROM clinicstaff WHERE cs_username=?";
    
    public ClinicStaffDAO(){
        
    }
    
     protected static Connection getConnection() throws SQLException {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Connection Established");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Unable to get connection");
        }

        return con;
    }
     
    public ClinicStaff selectStaffByUsername(String staff_username) throws SQLException{
        ClinicStaff staff = null;
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_STAFF_BY_USERNAME)) {
            ps.setString(1, staff_username);
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String password = rs.getString("cs_password");
                String name = rs.getString("cs_name");
                String phonenumber = rs.getString("cs_phonenumber");
                staff = new ClinicStaff(staff_username, name,  phonenumber,  password);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return staff;
    }
   
    private static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
