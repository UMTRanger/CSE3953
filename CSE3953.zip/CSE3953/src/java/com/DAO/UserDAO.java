/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

    private static final String jdbcURL = "jdbc:mysql://localhost:3306/cse3953_clinic";
    private static final String jdbcUsername = "root";
    private static final String jdbcPassword = "admin";

    private static final String SELECT_PATIENT_USERNAME = "SELECT p_username FROM patient WHERE p_username=?";
    private static final String SELECT_PATIENT_PASSWORD = "SELECT p_password FROM patient WHERE p_username=?";
    private static final String SELECT_STAFF_PASSWORD = "SELECT cs_password FROM clinicstaff WHERE cs_username=?";
    private static final String SELECT_DOCTOR_PASSWORD = "SELECT d_password FROM doctor WHERE d_username=?";

    public UserDAO() {
    }

    protected static Connection getConnection() throws SQLException {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Connection Established");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Unable to get connection");
        }

        return con;
    }

    public boolean isUsernameTaken(String username) throws SQLException {
       boolean isTaken = false;

        try {
            Connection con = UserDAO.getConnection();
            PreparedStatement ps = con.prepareStatement("select p_username from patient where p_username=?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                isTaken = true;
            }
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return isTaken;
    }

    public boolean isUserValid(String username, String password, String userType) {
        boolean isValid = false;

        if (userType.equalsIgnoreCase("patient")) {
            try {
                Connection con = PatientDAO.getConnection();
                PreparedStatement ps = con.prepareStatement(SELECT_PATIENT_PASSWORD);
                ps.setString(1, username);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    String storedPassword = rs.getString("p_password");
                    isValid = password.equals(storedPassword);
                }
                con.close();
            } catch (SQLException ex) {
                printSQLException(ex);
            }
        }

        if (userType.equalsIgnoreCase("staff")) {
            try {
                Connection con = PatientDAO.getConnection();
                PreparedStatement ps = con.prepareStatement(SELECT_STAFF_PASSWORD);
                ps.setString(1, username);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    String storedPassword = rs.getString("cs_password");
                    isValid = password.equals(storedPassword);
                }
                con.close();
            } catch (SQLException ex) {
                printSQLException(ex);
            }
        }

        if (userType.equalsIgnoreCase("doctor")) {
            try {
                Connection con = PatientDAO.getConnection();
                PreparedStatement ps = con.prepareStatement(SELECT_DOCTOR_PASSWORD);
                ps.setString(1, username);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    String storedPassword = rs.getString("d_password");
                    isValid = password.equals(storedPassword);
                }
                con.close();
            } catch (SQLException ex) {
                printSQLException(ex);
            }
        }

        return isValid;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
