package com.DAO;

import com.Model.Availability;
import com.Model.Doctor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AvailabilityDAO {

    private static final String jdbcURL = "jdbc:mysql://localhost:3306/cse3953_clinic";
    private static final String jdbcUsername = "root";
    private static final String jdbcPassword = "admin";

    private final String INSERT_DATE = "INSERT INTO availability (d_username, unavailableDate, reason) VALUES (?,?,?)";
    private final String SELECT_DATE_BY_USERNAME = "SELECT available_id, unavailableDate, reason FROM availability WHERE d_username=?";
    private final String SELECT_ALL_DATE = "SELECT * FROM availability";
    private final String DELETE_DATE = "DELETE FROM availability WHERE available_id=?";

    
    public AvailabilityDAO() {

    }

    protected static Connection getConnection() throws SQLException {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            System.out.println("Connection Established");

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Unable to get connection");
        }

        return con;
    }

    public void insertLeave(Availability availability) throws SQLException {
        System.out.println(INSERT_DATE);

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(INSERT_DATE)) {
            ps.setString(1, availability.getDoctor_username());
            ps.setString(2, availability.getUnavailableDate());
            ps.setString(3, availability.getReason());

            System.out.println(ps);
            ps.executeUpdate();

        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Availability selectDate(String d_username) throws SQLException {
        Availability availability = null;

        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_DATE_BY_USERNAME)) {
            ps.setString(1, d_username);
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String available_id = rs.getString("available_id");
                String unavailableDate = rs.getString("unavailableDate");
                String reason = rs.getString("reason");

                availability = new Availability(available_id, unavailableDate, reason);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return availability;
    }
    
    public List<Availability> selectAllDate() throws SQLException{
        List<Availability> availability = new ArrayList<>();
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(SELECT_ALL_DATE);) {
            System.out.println(ps);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int available_id = rs.getInt("available_id");
                String doctor_username = rs.getString("d_username");
                String unavailableDate = rs.getString("unavailableDate");
                String reason = rs.getString("reason");
                availability.add(new Availability(available_id, doctor_username, unavailableDate, reason));
            }
        }
        
        return availability;
    }
    
    public boolean deleteDate(int id) throws SQLException{
        boolean date_deleted;
        
        try ( Connection con = getConnection();  PreparedStatement ps = con.prepareStatement(DELETE_DATE);) {
            ps.setInt(1, id);
            date_deleted = ps.executeUpdate() > 0;
        }
        
        return date_deleted;
        
    }
    
    
    private static void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
